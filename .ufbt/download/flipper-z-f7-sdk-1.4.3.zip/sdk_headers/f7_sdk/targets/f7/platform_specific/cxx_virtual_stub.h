#pragma once
#include <errno.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

void __cxa_pure_virtual(void);

#ifdef __cplusplus
}
#endif
