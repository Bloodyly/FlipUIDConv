#pragma once
#include "notification.h"

#ifdef __cplusplus
extern "C" {
#endif

extern const NotificationMessage message_click;
extern const NotificationMessage message_note_c0;
extern const NotificationMessage message_note_cs0;
extern const NotificationMessage message_note_d0;
extern const NotificationMessage message_note_ds0;
extern const NotificationMessage message_note_e0;
extern const NotificationMessage message_note_f0;
extern const NotificationMessage message_note_fs0;
extern const NotificationMessage message_note_g0;
extern const NotificationMessage message_note_gs0;
extern const NotificationMessage message_note_a0;
extern const NotificationMessage message_note_as0;
extern const NotificationMessage message_note_b0;
extern const NotificationMessage message_note_c1;
extern const NotificationMessage message_note_cs1;
extern const NotificationMessage message_note_d1;
extern const NotificationMessage message_note_ds1;
extern const NotificationMessage message_note_e1;
extern const NotificationMessage message_note_f1;
extern const NotificationMessage message_note_fs1;
extern const NotificationMessage message_note_g1;
extern const NotificationMessage message_note_gs1;
extern const NotificationMessage message_note_a1;
extern const NotificationMessage message_note_as1;
extern const NotificationMessage message_note_b1;
extern const NotificationMessage message_note_c2;
extern const NotificationMessage message_note_cs2;
extern const NotificationMessage message_note_d2;
extern const NotificationMessage message_note_ds2;
extern const NotificationMessage message_note_e2;
extern const NotificationMessage message_note_f2;
extern const NotificationMessage message_note_fs2;
extern const NotificationMessage message_note_g2;
extern const NotificationMessage message_note_gs2;
extern const NotificationMessage message_note_a2;
extern const NotificationMessage message_note_as2;
extern const NotificationMessage message_note_b2;
extern const NotificationMessage message_note_c3;
extern const NotificationMessage message_note_cs3;
extern const NotificationMessage message_note_d3;
extern const NotificationMessage message_note_ds3;
extern const NotificationMessage message_note_e3;
extern const NotificationMessage message_note_f3;
extern const NotificationMessage message_note_fs3;
extern const NotificationMessage message_note_g3;
extern const NotificationMessage message_note_gs3;
extern const NotificationMessage message_note_a3;
extern const NotificationMessage message_note_as3;
extern const NotificationMessage message_note_b3;
extern const NotificationMessage message_note_c4;
extern const NotificationMessage message_note_cs4;
extern const NotificationMessage message_note_d4;
extern const NotificationMessage message_note_ds4;
extern const NotificationMessage message_note_e4;
extern const NotificationMessage message_note_f4;
extern const NotificationMessage message_note_fs4;
extern const NotificationMessage message_note_g4;
extern const NotificationMessage message_note_gs4;
extern const NotificationMessage message_note_a4;
extern const NotificationMessage message_note_as4;
extern const NotificationMessage message_note_b4;
extern const NotificationMessage message_note_c5;
extern const NotificationMessage message_note_cs5;
extern const NotificationMessage message_note_d5;
extern const NotificationMessage message_note_ds5;
extern const NotificationMessage message_note_e5;
extern const NotificationMessage message_note_f5;
extern const NotificationMessage message_note_fs5;
extern const NotificationMessage message_note_g5;
extern const NotificationMessage message_note_gs5;
extern const NotificationMessage message_note_a5;
extern const NotificationMessage message_note_as5;
extern const NotificationMessage message_note_b5;
extern const NotificationMessage message_note_c6;
extern const NotificationMessage message_note_cs6;
extern const NotificationMessage message_note_d6;
extern const NotificationMessage message_note_ds6;
extern const NotificationMessage message_note_e6;
extern const NotificationMessage message_note_f6;
extern const NotificationMessage message_note_fs6;
extern const NotificationMessage message_note_g6;
extern const NotificationMessage message_note_gs6;
extern const NotificationMessage message_note_a6;
extern const NotificationMessage message_note_as6;
extern const NotificationMessage message_note_b6;
extern const NotificationMessage message_note_c7;
extern const NotificationMessage message_note_cs7;
extern const NotificationMessage message_note_d7;
extern const NotificationMessage message_note_ds7;
extern const NotificationMessage message_note_e7;
extern const NotificationMessage message_note_f7;
extern const NotificationMessage message_note_fs7;
extern const NotificationMessage message_note_g7;
extern const NotificationMessage message_note_gs7;
extern const NotificationMessage message_note_a7;
extern const NotificationMessage message_note_as7;
extern const NotificationMessage message_note_b7;
extern const NotificationMessage message_note_c8;
extern const NotificationMessage message_note_cs8;
extern const NotificationMessage message_note_d8;
extern const NotificationMessage message_note_ds8;
extern const NotificationMessage message_note_e8;
extern const NotificationMessage message_note_f8;
extern const NotificationMessage message_note_fs8;
extern const NotificationMessage message_note_g8;
extern const NotificationMessage message_note_gs8;
extern const NotificationMessage message_note_a8;
extern const NotificationMessage message_note_as8;
extern const NotificationMessage message_note_b8;

/**
 * @brief Returns the frequency of the given note
 *
 * This function calculates and returns the frequency (in Hz) of the specified note.
 * If the input note name is invalid, the function returns 0.0.
 *
 * @param [in] note_name The name of the note (e.g., "A4", cs5")
 * @return The frequency of the note in Hz, or 0.0 if the note name is invalid
 */
extern float notification_messages_notes_frequency_from_name(const char* note_name);

#ifdef __cplusplus
}
#endif
