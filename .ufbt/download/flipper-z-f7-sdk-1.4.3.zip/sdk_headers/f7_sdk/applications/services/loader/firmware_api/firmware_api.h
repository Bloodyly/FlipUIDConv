#pragma once

#include <flipper_application/elf/elf_api_interface.h>

extern const ElfApiInterface* const firmware_api_interface;
